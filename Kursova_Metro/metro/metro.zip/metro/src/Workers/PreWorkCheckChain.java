package Workers;

// PreWorkCheckChain class
public class PreWorkCheckChain {
    private PreWorkCheck[] checks;

    public PreWorkCheckChain() {
        // Initialize the chain of checks
        checks = new PreWorkCheck[]{
                new MedicalCheck(),
                new PsychologicalCheck(),
                new TechnicalKnowledgeCheck()
        };
    }

    public boolean executeChecks(Worker worker) {
        for (PreWorkCheck check : checks) {
            if (!check.check(worker)) {
                return false;
            }
        }
        return true;
    }
}
