package Momento;

import AlertSystem.LineAlertSystem;
import Station.Station;

import java.util.LinkedList;

public class MetroLineOriginator {

    public static MetroLineOriginator originator = new MetroLineOriginator();

    public LinkedList<Station> stations = new LinkedList<>();
    public LinkedList<LineAlertSystem> alertSystems = new LinkedList<>();



}
