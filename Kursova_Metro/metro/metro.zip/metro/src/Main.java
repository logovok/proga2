import Momento.Caretaker;

public class Main {
    public static void main(String[] args) {

        Caretaker caretaker = new Caretaker();
        caretaker.takeCare();


    }
}